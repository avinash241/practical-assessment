import { Component, Input, OnInit } from '@angular/core';

import { ProfilesService } from '../../services/profiles.service';
import { Profile } from '../../models/profiles';

@Component({
  selector: 'app-profile-item',
  templateUrl: './profile-item.component.html',
  styleUrls: ['./profile-item.component.css'],
})
export class ProfileItemComponent implements OnInit {
  constructor(private profileService: ProfilesService) {}
  @Input() profile: Profile;

  ngOnInit(): void {}
}
