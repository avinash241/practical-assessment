import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CreateProfile } from '../../models/create-profile';
import { CreateProfileService } from '../../services/create-profile.service';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.css'],
})
export class CreateProfileComponent implements OnInit {
  createProfile: CreateProfile = new CreateProfile();
  constructor(
    private createProfileService: CreateProfileService,
    private router: Router
  ) {}
  createProfileSubmit() {
    this.createProfileService.createProfile(this.createProfile).subscribe(
      (res) => {
        console.log('success');
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }

  ngOnInit(): void {}
}
